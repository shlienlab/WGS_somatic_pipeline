get.cds.gene.length <- function(gene=NULL, mart=NULL) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  if (is.null(mart)) stop("Mandatory argument mart is missing")

  ens.biomart.cds.length <- as.vector(getBM(
    values=as.matrix(gene),
    filters=c('ensembl_gene_id'),
    attributes=c('cds_length'),
    mart=mart
    )$cds_length)
  return(max(ens.biomart.cds.length))
  }