### fliter_clips.R #############################################################################
# A R script that loads an a mutation dataframe and associated BAM file and creates a dataframe where all hard clippings are flagged

### HISTORY #######################################################################################
# Version           Date            Developer               Comments
# 0.01              2016-12-08      chrissy                 initial development
# 0.02              2017-04-12      rdeborja                Rscript now copied to exec directory

### NOTES #########################################################################################

### PREAMBLE ######################################################################################
library('getopt')

usage <- function() {
  usage.text <- '\nUsage: filter_clips.R --bam test.bam --rda test.rda --sample sam --offsets 10\n\n'
  return(usage.text)
}

params = matrix(
  c(
	'bam', 'b', 1, 'character',
  	'rda', 'r', 1, 'character',
  	'sample', 's', 0, 'character',
	'offsets', 'o', 0, 'integer'
	),
  ncol = 4,
  byrow = TRUE
)

opt = getopt(params)

# verify arguments
if(is.null(opt$bam)) { stop(usage()) }
if(is.null(opt$rda)) { stop(usage()) }

### LIBRARIES #####################################################################################
library(ShlienLab.Core.Filter)

### FUNCTIONS #####################################################################################
filter_clips <- function(rda = NULL, bam = NULL) {
  hard.filtered <- count_rda_clips(bam = bam, rda = rda, operation = "H")
  soft.filtered <- count_rda_clips(bam = bam, rda = hard.filtered, offsets = 30)
  return(soft.filtered)
}

### GET DATA ######################################################################################

### PROCESS DATA ##################################################################################

### ANALYSIS ######################################################################################
data.filtered <- filter_clips(rda=opt$rda, bam=opt$bam)
output.file <- ifelse(is.null(opt$sample), "annotated_filtered_clipped.rda", paste(opt$sample, "annotated_filtered_clipped.rda", sep="_"))
save(x=data.filtered, file=output.file)

### PLOTTING ######################################################################################

### SESSION INFORMATION ###########################################################################
sessionInfo()
