load.human.biomart <- function(version = NULL, host='feb2014.archive.ensembl.org') {
  if (is.null(version)) {
    return(useDataset(dataset = 'hsapiens_gene_ensembl', mart = useMart(host=host, biomart='ENSEMBL_MART_ENSEMBL')));    
  } else {
    version = paste(sep = '_', 'ensembl', 'mart', version);
    return(useDataset(dataset = 'hsapiens_gene_ensembl', mart = useMart(biomart = version, archive = TRUE, host=host)));    
    }
  }
