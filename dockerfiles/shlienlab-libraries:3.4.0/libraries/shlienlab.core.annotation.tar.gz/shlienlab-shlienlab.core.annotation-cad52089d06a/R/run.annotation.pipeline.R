 run.annotation.pipeline <- function(path = NULL, tcga = FALSE) {
  if (is.null(path)) stop("Missing path to the annovar annotated files")
  multianno.files <- get.list.of.multianno.files(path = path)
  if (tcga == FALSE) {
    data <- import.multianno.data(files = multianno.files) 
  } else {
    data <- import.maf.multianno.data(files = multianno.files)
    }
  data$aa <- apply(X = as.matrix(data$annovar_annotation), MARGIN = 1, FUN = add.aminoacid.column)
  data <- add.mutation.column(data = data)
  data$trinuc <- apply(X = as.matrix(data[,c('context', 'ref_allele', 'alt_allele')]), MARGIN = 1, FUN = add.trinucleotide)
  data <- add.mutation.trinuc(data = data)
  data$ensembl_gene <- apply(X = as.matrix(data$annovar_ens_gene), MARGIN = 1, FUN = remove.multiple.genes)
  data$hgnc_gene <- apply(X = as.matrix(data$annovar_gene), MARGIN = 1, FUN = remove.multiple.genes)
  data$cosmic_census <- filter.for.cosmic.cancer.gene.census(data = data$hgnc_gene)
  return(data);
  }
