load.grch37.biomart <- function(biomart='ENSEMBL_MART_ENSEMBL') {
  require('biomaRt')
  host <- 'grch37.ensembl.org'
  return(biomaRt::useDataset(dataset='hsapiens_gene_ensembl', mart = biomaRt::useMart(host=host, biomart='ENSEMBL_MART_ENSEMBL')))
  }
