import.gatk.annovar.snv.data <- function(path=NULL) {
  if (is.null(path)) stop("Mandatory argument path is missing")
  
  data <- data.frame()
  tmp.data <- data.frame()
  files <- list.files(
    path=path,
    pattern='annovar.hg19_multianno.txt',
    full.names=TRUE,
    recursive=FALSE
    )
  for(i in 1:length(files)) {
    samplename <- unlist(strsplit(x=basename(files[i]), split='\\.'))[1]
    tmp.data <- read.table(
      file=files[i],
      header=FALSE,
      as.is=TRUE,
      sep='\t',
      quote="\"",
      comment.char='#',
      skip=1
      )
    tmp.data$SampleName <- samplename
    tmp.data$Filename <- files[i]
    data <- rbind(data, tmp.data)
    }
  col.header <- c(
    'Chr',
    'Start',
    'End',
    'Ref',
    'Alt',
    'Func.refGene',
    'Gene.refGene',
    'ExonicFunc.refGene',
    'AAChange.refGene',
    'Func.ensGene',
    'Gene.ensGene',
    'ExonicFunc.ensGene',
    'AAChange.ensGene',
    'snp132',
    'a1000g',
    'esp',
    'cg69',
    'cosmic67',
    'bed',
    'vaf',
    'qual',
    'depth',
    'SampleName',
    'Filename'
    )
  colnames(data) <- col.header
  
  return(data)
  }