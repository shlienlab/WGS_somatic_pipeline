convert_indel_to_granges <- function(data=NULL) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  
  data <- GenomicRanges::makeGRangesFromDataFrame(
    df=data,
    keep.extra.columns=TRUE,
    seqnames.field=c('annovar_chr'),
    start.field=c('annovar_start'),
    end.field=c('annovar_end')
    )
  return(data)
  }
