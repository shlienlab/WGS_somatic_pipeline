get.coding.mutations <- function(data=NULL, func=c('nonsynonymous SNV', 'stopgain SNV', 'stoploss SNV', 'splicing')) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  
  # we're only interested in those mutations that are predicted to have an effect on
  # the coding regions including splicing events
  data.exonic <- data %>% filter(annovar_exonic_func %in% func)
  data.exonic[data.exonic$annovar_func == 'splicing',]
  data.splicing <- data %>% filter(annovar_func %in% func)
  
  return(rbind(data.exonic, data.splicing))
  }