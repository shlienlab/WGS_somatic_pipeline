get.biomart.gene.biotype <- function(data, mart) {
  if (is.null(data)) stop("Missing data");
  ens.biomart.gene <- getBM(values = as.matrix(data$ensembl_gene), filters = c('ensembl_gene_id'), attributes = c('ensembl_gene_id', 'gene_biotype'), mart = mart, uniqueRows = FALSE);
  colnames(ens.biomart.gene) <- c('ensembl_gene', 'gene_biotype');
  return(join(x = data, y = ens.biomart.gene, by = 'ensembl_gene', match = 'first', type = 'left'));
  }
