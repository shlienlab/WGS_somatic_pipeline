get.genes.from.data <- function(data = NULL, genes = NULL) {
  if (is.null(data)) stop('Mandatory argument data is missing')
  if (is.null(genes)) stop('Mandatory argument genes is missing')
  if (!is.character(genes)) stop('genes must be a character vector of gene names')
  
  return(data[data$hgnc_gene %in% genes,])
  }