create.cigar.dataframe <- function(cigar=NULL, pos=NULL) {
  if (is.null(cigar)) stop("Mandatory argument cigar is missing")
  if (is.null(pos)) stop("Mandatory argument pos is missing")
  
  cigar.size <- unlist(strsplit(x=cigar, split="[MIDNSHPX=]", perl=TRUE))
  cigar.size <- as.numeric(cigar.size)
  cigar.type <- unlist(strsplit(x=cigar, split="[0-9]+", perl=TRUE))
  cigar.type <- as.character(cigar.type)
  cigar.type <- cigar.type[2:length(cigar.type)]
  cigar.df <- data.frame(type=cigar.type, size=cigar.size)
  cigar.df$start <- NA
  cigar.df$end <- NA
  cigar.offset <- 0
  for(i in 1:nrow(cigar.df)) {
    cigar.df$start[i] <- pos + cigar.offset
    cigar.df$end[i] <- pos + cigar.offset + cigar.size[i] - 1
    cigar.offset <- cigar.offset + cigar.size[i]
    }
  return(cigar.df)
  }