calculate.vaf <- function(x=NULL) {
  if (is.null(x)) stop("Mandatory argument x is missing")
  
  if (is.na(x[1] | is.na(x[2]))) {
    return(NA)
  } else {
    return(x[1] / sum(x[1], x[2]))
    }
  }
