add.mutation.trinuc <- function(data) {
  data$mutation.trinuc <- paste(sep = '-', data$mutation.type, data$trinuc);
  return(data)
  }
