get.gene.symbol <- function(data=NULL, mart=NULL) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  if (is.null(mart)) stop("Mandatory argument mart is missing")
  bm_filters = c('chromosome_name', 'start', 'end')
  bm_attributes = c('hgnc_symbol')
  hgnc_gene_symbols <- data.frame()
  hgnc_gene_symbols <- getBM(
    values=as.list(data),
    filters=bm_filters,
    attributes=bm_attributes,
    mart=mart
    )
  
  # if there is only one row in hgnc_gene_symbols, return that value, otherwise, concatenate the rows into
  # a single string and return that
  gene <- character()
  if (nrow(hgnc_gene_symbols) == 1) {
    gene <- hgnc_gene_symbols$hgnc_symbol
    #return(hgnc_gene_symbols$hgnc_symbol)
  } else if (nrow(hgnc_gene_symbols) == 0) {
    gene <- NULL
    #    return(NULL)
  } else if (nrow(hgnc_gene_symbols) > 1) {
    gene <- as.character(apply(X=hgnc_gene_symbols, MARGIN=2, FUN=paste, collapse=','))
    }
  return(gene)
  }
