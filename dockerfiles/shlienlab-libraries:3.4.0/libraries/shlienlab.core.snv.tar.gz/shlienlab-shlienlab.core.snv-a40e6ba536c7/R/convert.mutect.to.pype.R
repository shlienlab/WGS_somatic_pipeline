convert.mutect.to.pype <- function(file = NULL) {
  if (is.null(file)) stop("Mandatory argument file is missing")
  
  data <- load(file)
  output <- gsub(x=basename(file), pattern='rda$', replacement='pype.txt')
  pype.data <- reorder.mutect.data.to.pype(data=get(data))
  colnames(pype.data) <- get.mutect.pype.header()
  write.table(
    x=pype.data,
    file=output,
    row.names=FALSE,
    quote=FALSE,
    sep='\t'
    )
  return(output)
  }
