get.ensembl.gene <- function(data) {
  mart <- biomaRt::useMart('ensembl');
  mart <- biomaRt::useDataset('hsapiens_gene_ensembl', mart);
  for(i in 1:nrow(data)) {
    data$ensembl_gene[i] <- biomaRt::getBM(
      values = list(sub(x = data$contig[i], pattern = '^chr', replacement = ''), data$position[i], data$position[i]),
      filters = c('chromosome_name', 'start', 'end'),
      attributes = c('ensembl_gene_id'),
      mart = mart
      );    
    }
  return(data);
  }