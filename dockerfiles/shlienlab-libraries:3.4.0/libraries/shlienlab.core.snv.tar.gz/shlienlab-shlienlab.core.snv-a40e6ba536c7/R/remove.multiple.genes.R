remove.multiple.genes <- function(data) {
  first.gene <- unlist(strsplit(x = data, split = '[(,;]', perl = TRUE))[1];
  return(first.gene);
  }
