# a simple function that returns the first instance of the annotation
# this function should be used within an apply to go through the dataframe
# on a row basis
# use this within an apply function
# apply(X = as.matrix(data$annovar_annotation), MARGIN = 1, FUN = add.aminoacid.column)
add.aminoacid.column <- function(data) {
  aa <- unlist(strsplit(x = data, split = "[:,]", perl = TRUE))[5]
  return(aa);
  }
