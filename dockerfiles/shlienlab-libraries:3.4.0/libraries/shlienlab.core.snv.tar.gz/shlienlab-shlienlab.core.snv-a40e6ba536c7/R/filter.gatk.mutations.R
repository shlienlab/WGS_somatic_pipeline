filter.gatk.mutations <- function(data=NULL, vaf.min=0, qual.min=0) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  
  filtered.data <- data %>%
    filter(snp132 == '') %>%
    filter(is.na(cg69) | cg69 == 0) %>%
    filter(is.na(a1000g) | a1000g == 0) %>%
    filter(is.na(esp) | esp == 0) %>%
    filter(vaf > vaf.min) %>%
    filter(qual > qual.min)
  
  return(filtered.data)
  }