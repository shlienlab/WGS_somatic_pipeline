get.list.of.multianno.files <- function(path = '.', pattern = 'hg19_multianno.txt$', recursive = TRUE) {
  files <- list.files(
    path = path,
    pattern = pattern,
    recursive = TRUE,
    full.names = TRUE
    );
  return(files);
  }
