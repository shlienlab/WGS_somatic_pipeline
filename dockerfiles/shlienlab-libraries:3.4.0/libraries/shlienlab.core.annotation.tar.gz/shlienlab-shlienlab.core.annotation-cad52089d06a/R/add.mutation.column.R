add.mutation.column <- function(data) {
  # add an extra column to the dataframe containing the mutation genotype
  data$mutation.type <- paste(
    sep = '>',
    data$ref_allele,
    data$alt_allele
    );
  
  # based on the Ludmil paper "Deciphering Signatures of Mutations Processes
  # Operating in Human Cancer," limit the mutations in the MuTect dataframe
  # to only C>N and T>N mutations
  data$mutation.type <- sub(
    pattern = 'G>T', replacement = 'C>A', x = data$mutation.type
    );
  data$mutation.type <- sub(
    pattern = 'G>C', replacement = 'C>G', x = data$mutation.type
    );
  data$mutation.type <- sub(
    pattern = 'G>A', replacement = 'C>T', x = data$mutation.type
    );
  data$mutation.type <- sub(
    pattern = 'A>T', replacement = 'T>A', x = data$mutation.type
    );
  data$mutation.type <- sub(
    pattern = 'A>G', replacement = 'T>C', x = data$mutation.type
    );
  data$mutation.type <- sub(
    pattern = 'A>C', replacement = 'T>G', x = data$mutation.type
    );  
  return(data);
  }
