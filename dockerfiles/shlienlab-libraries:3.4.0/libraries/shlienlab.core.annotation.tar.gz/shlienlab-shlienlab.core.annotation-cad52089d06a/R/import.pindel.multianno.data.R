import.pindel.multianno.data <- function(files = NULL) {
  if (is.null(files)) stop("Mandatory argument files is missing")
  
  data <- data.frame()
  for(i in 1:length(files)) {
    tmp.data <- read.table(
      file = files[i],
      header = FALSE,
      as.is = TRUE,
      sep = "\t",
      quote = "\"",
      skip = 1
      )
    data <- rbind(data, tmp.data)
    }
  # ANNOVAR produces insufficient column headers, we add our own to coincide with the standard
  # SNV headers
  colnames(data) <- c(
    'annovar_chr',
    'annovar_start',
    'annovar_end',
    'annovar_ref',
    'annovar_alt',
    'annovar_func',
    'annovar_gene',
    'annovar_exonic_func',
    'annovar_annotation',
    'annovar_ens_func',
    'annovar_ens_gene',
    'annovar_ens_exonic_func',
    'annovar_ens_annotation',
    'annovar_dbsnp',
    'annovar_1000g',
    'annovar_esp',
    'annovar_complete_genomics',
    'annovar_cosmic',
    'annovar_clinvar',
    'annovar_exac',
    'annovar_target',
    'zygosity',
    'null1',
    'null2'
    )
  # remove the last 2 columns as they don't provide useful data
  data$null1 <- NULL
  data$null2 <- NULL
  return(data)
  }