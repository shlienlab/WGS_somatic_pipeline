merge.sample.somatic.snv.dataframes <- function(path=NULL, pattern='_annotated.rda$', recursive=TRUE) {
  if (is.null(path)) stop("Mandatory argument path is missing")
  
  files <- list.files(path=path, pattern=pattern, recursive=recursive, full.names=TRUE)
  tmp.data <- data.frame()
  for(i in 1:length(files)) {
    load(files[i])
    data <- data %>% filter(judgement == 'KEEP')
    tmp.data <- rbind(tmp.data, data)
    rm(data)
    gc()
    }
  return(tmp.data)
  }
