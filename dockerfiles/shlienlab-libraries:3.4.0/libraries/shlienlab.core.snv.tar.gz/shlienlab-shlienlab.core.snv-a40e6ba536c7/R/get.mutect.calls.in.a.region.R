get.mutect.calls.in.a.region <- function(data=NULL, chr=NULL, start=NULL, end=NULL) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  if (is.null(chr)) stop("Mandatory argument chr is missing")
  if (is.null(start)) stop("Mandatory argument start is missing")
  if (is.null(end)) stop("Mandatory argument end is missing")
  
  require(dplyr)
  data <- data %>% filter(annovar_chr == chr) %>% filter(annovar_start >= start) %>% filter(annovar_end <= end)
  return(data)
  }
