filter.somatic.mutations <- function(data=NULL, coverage=TRUE, source='WXS', exac=0.001, vaf=0.0) {
  if (is.null(data)) stop("Mandatory argument data is missing")

  # check for valid entries for the source argument
  if (!(source %in% c('WGS', 'WXS', 'CPANEL')) & coverage == TRUE) stop("Invalid source argument, must be one of WGS, WXS, or CPANEL")
  
  # use MuTect's internal filter to keep those that are classified as KEEP in the judgement column
  data <- data %>% filter(judgement == 'KEEP')

  if (coverage == TRUE) {
    if (source == 'WXS') {
      data <- data %>%
        filter((n_ref_count + n_alt_count) >= 20 | normal_name == 'none') %>%
        filter((t_ref_count + t_alt_count) >= 30)
    } else if (source == 'WGS') {
      data <- data %>%
        filter((n_ref_count + n_alt_count) >= 10 | normal_name == 'none') %>%
        filter(t_ref_count + t_alt_count >= 10)
    } else if (source == 'CPANEL') {
      data <- data %>%
        filter((n_ref_count + n_alt_count) >= 50 | normal_name == 'none') %>%
        filter(t_ref_count + t_alt_count >= 50)
    } else {
      stop("Invalid source, must be either WGS, WXS, or CPANEL")
      }
    }

  # check if clinvar was used to filter the data (older data sets may not have this)
  if ('annovar_clinvar' %in% names(data)) {
    data <- data %>%
      filter(dbsnp_site != 'DBSNP' | grepl(x=annovar_clinvar, pattern='CLIN')) %>%
      filter(is.na(annovar_dbsnp) | annovar_dbsnp == '' | annovar_dbsnp == 0 | grepl(x=annovar_clinvar, pattern='CLIN')) %>%
      filter(is.na(annovar_complete_genomics) | annovar_complete_genomics != '' | annovar_complete_genomics == 0 | grepl(x=annovar_clinvar, pattern='CLIN')) %>%
      filter(is.na(annovar_1000g) | annovar_1000g == '' | annovar_1000g == 0 | grepl(x=annovar_clinvar, pattern='CLIN'))
  } else {
    data <- data %>%
      filter(dbsnp_site != 'DBSNP') %>%
      filter(is.na(annovar_dbsnp) | annovar_dbsnp == '' | annovar_dbsnp == 0) %>%
      filter(is.na(annovar_complete_genomics) | annovar_complete_genomics == '' | annovar_complete_genomics == 0) %>%
      filter(is.na(annovar_1000g) | annovar_1000g == '' | annovar_1000g == 0)
    }
  
  # filter variants based on their variant allele fraction
  data <- data %>% filter(tumor_f >= vaf)
  
  # there is an exome specific filter that can be applied using the ExAC and ESP databases
  if ('annovar_exac' %in% names(data) & source == 'WXS') {
    data <- data %>%
      filter(annovar_exac <= exac | is.na(annovar_exac)) %>%
      filter(is.na(annovar_esp) | annovar_esp == '' | annovar_esp == 0 | grepl(x=annovar_clinvar, pattern='CLIN'))
    }
  return(data)
  }
