# this function can be used within an "apply" function from the caller.
# the function takes in a vector containing MuTect columns: context, ref_allele, alt_allele
# e.g. data$trinuc <- apply(X = data[,c('context', 'ref_allele', 'alt_allele')], MARGIN = 1, FUN = add.trinucleotide)
add.trinucleotide <- function(data) {
  base_for_complement <- c('G', 'A');
  context.vector <- unlist(strsplit(x = data[1], split = ''));
  trinucleotide <- paste(sep = '', context.vector[3], data[2], context.vector[5]);
  if(data[2] %in% base_for_complement) {
    trinuc.dna.string <- DNAString(x = trinucleotide);
    trinucleotide <- as.character(reverseComplement(x = trinuc.dna.string));
    }
  return(trinucleotide);
  }
