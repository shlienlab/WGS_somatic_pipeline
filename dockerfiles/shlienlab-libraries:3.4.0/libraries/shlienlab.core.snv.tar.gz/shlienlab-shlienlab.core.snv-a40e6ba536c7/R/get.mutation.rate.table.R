get.mutation.rate.table <- function(data=NULL, feature='tumor_name', library.type='WGS') {
  if (is.null(data)) stop("Mandatory argument data is missing")
  if (is.null(feature)) stop("Mandatory argument feature is missing")
  
  mut.rate.table <- as.data.frame(table(data[,c(feature)]))
  colnames(mut.rate.table) <- c('sample', 'count')
  if (library.type == 'WGS') {
    mut.rate.table <- mut.rate.table %>% mutate(mutation_rate = count / 2800)
  } else if (library.type == 'WXS') {
    mut.rate.table <- mut.rate.table %>% mutate(mutation_rate = count / 30)
  } else if (library.type == 'CPANEL') {
    mut.rate.table <- mut.rate.table %>% mutate(mutation_rate = count / 3.955)
  } else {
    stop("Invalid library.type")
    }
  return(mut.rate.table[order(mut.rate.table$mutation_rate, decreasing = TRUE),])
  }
