cromwell_get.mutect2.data <- function(files, load_vcfs = TRUE) {
  # Annovar files to process
  annovar_files <- files
  
  # Two dataframes that will be vertically concatenated to give the result
  annovar_data <- data.frame()
  if (load_vcfs)
    vcf_data <- data.frame()
  
  for (annovar_file in annovar_files) {
    # Load the annovar results
    chr_annovar_data <- try(
      read.table(file = annovar_file, header = FALSE, as.is = TRUE, sep = '\t', quote = "\"", skip = 1),  
      silent = TRUE
    )
    # the "try" block will return a class of "try-error"
    if (class(chr_annovar_data) == 'try-error')
      next()
    annovar_data <- rbind(annovar_data, chr_annovar_data)
    
    if (load_vcfs) {
      # Load the results from the VCF
      vcf_file <- sub(".annovar.hg19_multianno.txt$", ".vcf", annovar_file)
      chrom <- sub('.*\\.(.+)\\.vcf$', '\\1', vcf_file)
      chr_vcf_data <- try(vcfR::vcfR2tidy(vcfR::read.vcfR(vcf_file, verbose=FALSE), verbose=FALSE))
      if (class(chr_vcf_data) == 'try-error') {
        # If any VCF files are missing, then we don't load any of them.
        load_vcfs = FALSE
        warning("Couldn't locate all of the corresponding VCF files, continuing without them.")
      }
      else {
        t <- chr_vcf_data$gt[chr_vcf_data$gt$Indiv == 'TUMOR',]
        g <- chr_vcf_data$gt[chr_vcf_data$gt$Indiv == 'NORMAL',]
        
        # Clean up each of these dataframes
        for (gt in c('g', 't')) {
          split <- stringr::str_split_fixed(get(gt)$gt_GT_alleles, '/', 2)
          
          assign(gt, get(gt) %>%
            dplyr::select(-gt_GT_alleles, -ChromKey, -Indiv) %>% 
            dplyr::rename(gt_POS = POS) %>%
            dplyr::mutate(gt_REF = split[,1], gt_ALT = split[,2]))
          
        }
        # Change gt_ prefix to g_ or t_ prefix
        colnames(g) <- sub('^gt(?=_)', 'g', colnames(g), perl=TRUE)
        colnames(t) <- sub('^gt(?=_)', 't', colnames(t), perl=TRUE)
        # Add g and t to the growing data of VCF FORMAT data
        vcf_data <- rbind(vcf_data, cbind(g %>% dplyr::rename(gt_POS=g_POS), t %>% dplyr::select(-t_POS)))
      }
    }
  }
  
  colnames(annovar_data) <- get.mutect2.annotated.header()
  if(load_vcfs)
    return(cbind(annovar_data, vcf_data))
  else
    return(annovar_data)
}
