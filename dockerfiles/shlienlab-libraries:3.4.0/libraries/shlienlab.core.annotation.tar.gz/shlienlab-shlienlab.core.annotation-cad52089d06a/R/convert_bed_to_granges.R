convert_bed_to_granges <- function(bed=NULL) {
  if (is.null(bed)) stop("Mandatory argument bed is missing")
  
  data <- read.table(
    file=bed,
    header=FALSE,
    as.is=TRUE,
    sep='\t',
    quote="\""
    )
  colnames(data) <- c('chr', 'start', 'end', 'name', 'score', 'strand')
  data <- makeGRangesFromDataFrame(df=data, keep.extra.columns=TRUE)
  return(data)
  }
