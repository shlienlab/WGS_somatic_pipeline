annotate_target <- function(data=NULL, target=NULL, colnam='in_target') {
  # validate passed arguments
  if (is.null(data)) stop("Mandatory argument data is missing")
  if (is.null(target)) stop("Mandatory argument cpanel_target is missing")
  
  in_target <- hiAnnotator::getSitesInFeature(
    sites.rd=data,
    features.rd=target,
    colnam=colnam
    )
  return(in_target)
  }
