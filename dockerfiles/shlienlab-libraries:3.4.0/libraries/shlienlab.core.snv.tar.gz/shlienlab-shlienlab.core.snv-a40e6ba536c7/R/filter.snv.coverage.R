filter.snv.coverage <- function(data=NULL) {
  if (is.null(data)) stop("Mandatory argument is missing")
  
  if (coverage == TRUE) {
    if (source == 'WXS') {
      data <- data %>%
        filter((n_ref_count + n_alt_count) >= 20 | normal_name == 'none') %>%
        filter((t_ref_count + t_alt_count) >= 30)
      }
    else if (source == 'WGS') {
      data <- data %>%
        filter((n_ref_count + n_alt_count) >= 10 | normal_name == 'none') %>%
        filter(t_ref_count + t_alt_count >= 10)
      }
    else if (source == 'CPANEL') {
      data <- data %>%
        filter((n_ref_count + n_alt_count) >= 50 | normal_name == 'none') %>%
        filter(t_ref_count + t_alt_count >= 50)
      }
    else {
      stop("Invalid source, must be either WGS, WXS, or CPANEL")
      }
    }
  
  
  }
