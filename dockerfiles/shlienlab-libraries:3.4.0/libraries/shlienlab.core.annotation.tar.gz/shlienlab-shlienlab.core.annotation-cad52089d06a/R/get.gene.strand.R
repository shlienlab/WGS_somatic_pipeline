get.gene.strand <- function(data, mart) {
  ens.biomart.gene <- getBM(values = as.matrix(data$ensembl_gene), filters = c('ensembl_gene_id'), attributes = c('ensembl_gene_id', 'strand'), mart = mart);
  colnames(ens.biomart.gene) <- c('ensembl_gene', 'strand')
  return(join(x = data, y = ens.biomart.gene, by = 'ensembl_gene', match = 'first', type = 'left'));
  }
