convert_snv_to_granges <- function(data=NULL) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  
  data <- makeGRangesFromDataFrame(df=data, keep.extra.columns=TRUE)
  return(data)
  }
