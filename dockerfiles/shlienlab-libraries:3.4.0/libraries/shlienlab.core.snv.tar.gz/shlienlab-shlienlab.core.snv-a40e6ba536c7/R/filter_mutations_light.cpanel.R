filter_mutations_light.cpanel = function (data = NULL) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  
  filtered.data <- data %>% filter(is.na(annovar_1000g) | annovar_1000g < 0.01)
  filtered.data =  data[ ( is.na(data$annovar_1000g) | (data$annovar_1000g < 0.01) ) &
                           ( is.na(data$annovar_esp) | (data$annovar_esp < 0.01) ) &
                           ( is.na(data$annovar_exac) | (data$annovar_exac < 0.01) ) &
                           data$t_alt_count >=10 &
                           data$n_alt_count <3 & 
                           data$n_ref_count > 50 &
                           data$tumor_f > 0.01 
                         ,]
  
  return(filtered.data)
  }
