# this function can be used within apply statement
# the order which data should be passed is as follows:
#  1. dbsnp_site
#  2. annovar_dbsnp
#  3. annovar_complete_genomics
#  4. annovar_1000g
#  5. annovar_exac
#  6. annovar_esp
#  7. annovar_clinvar

check.for.dbsnp.clinvar.snv <- function(x=NULL, exac_threshold=0.001) {
  if (is.null(data)) stop("Mandatory argument data is missing")

  # convert x to a dataframe
  x <- data.frame(dbsnp_site=x[1], annovar_dbsnp = x[2], annovar_complete_genomics = x[3], annovar_1000g = x[4], annovar_exac = x[5], annovar_esp = x[6], annovar_clinvar = x[7])
  x$annovar_exac <- as.numeric(x$annovar_exac)
  # check for annovar_clinvar with CLINSIG=pathogenic, if that does not exist filter out dbsnp, complete_genomics,
  # 100g, exac and esp
  if (!grepl(x=x$annovar_clinvar, pattern='CLINSIG=pathogenic')) {
    # if there's no regex for CLINSIG=pathogenic, we apply the database filters
    x <-x %>% filter(!grepl(x=dbsnp_site, pattern='^DBSNP$')) %>%
      filter(is.na(annovar_dbsnp) | annovar_dbsnp == '' | annovar_dbsnp == 0) %>%
      filter(is.na(annovar_complete_genomics) | annovar_complete_genomics == '' | annovar_complete_genomics == 0) %>%
      filter(is.na(annovar_1000g) | annovar_1000g == '' | annovar_1000g == 0) %>%
      filter(annovar_exac <= exac_threshold | is.na(annovar_exac)) %>%
      filter(is.na(annovar_esp) | annovar_esp == '' | annovar_esp == 0)
    return('FAIL')
    }
  # immediately give the filter column a "PASS" if it's clinically pathogenic in ClinVar
  else if (grepl(x=x$annovar_clinvar, pattern='CLINSIG=pathogenic')) {
    return('PASS')
    }
  else {
    return('NA')
    }
  }