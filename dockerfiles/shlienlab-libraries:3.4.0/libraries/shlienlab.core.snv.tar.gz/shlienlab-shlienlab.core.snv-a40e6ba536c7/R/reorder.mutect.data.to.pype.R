reorder.mutect.data.to.pype <- function(data=NULL) {
  if (is.null(data)) stop("Mandatory argument data is missing")
  
  return(
    data[
      c(
        "annovar_chr",
        "annovar_chr",
        "annovar_start",
        "annovar_end",
        "annovar_ref",
        "annovar_alt",
        "annovar_func",
        "annovar_gene",
        "tumor_f",
        "mutation.type",
        "trinuc",
        "n_ref_count",
        "n_alt_count",
        "t_ref_count",
        "t_alt_count"
        )
      ]
    )
  }
