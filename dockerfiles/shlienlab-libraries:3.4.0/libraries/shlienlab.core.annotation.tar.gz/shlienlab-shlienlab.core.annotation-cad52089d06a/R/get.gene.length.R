get.gene.length <- function(data, mart) {
  ens.biomart.gene <- getBM(values = as.matrix(data$ensembl_gene), filters = c('ensembl_gene_id'), attributes = c('ensembl_gene_id', 'start_position', 'end_position'), mart = mart);
  colnames(ens.biomart.gene) <- c('ensembl_gene', 'start', 'end')
  ens.biomart.gene$ensembl_gene_length <- ens.biomart.gene$end - ens.biomart.gene$start + 1
  ens.biomart.gene <- ens.biomart.gene[,c('ensembl_gene', 'ensembl_gene_length')]
  return(join(x = data, y = ens.biomart.gene, by = 'ensembl_gene', match = 'first', type = 'left'));
  }
