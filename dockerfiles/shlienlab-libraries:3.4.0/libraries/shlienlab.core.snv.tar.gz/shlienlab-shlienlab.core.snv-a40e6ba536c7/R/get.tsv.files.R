get.tsv.files <- function(path=NULL, pattern='.var.annotated.tsv$') {
  if (is.null(path)) stop("Mandatory argument path is missing")
  files <- list.files(path=path, pattern=pattern, recursive=TRUE ,full.names=TRUE)
  return(files)
  }
